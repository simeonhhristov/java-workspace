module com.example.task2_72072 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.task2_72072 to javafx.fxml;
    exports com.example.task2_72072;
}